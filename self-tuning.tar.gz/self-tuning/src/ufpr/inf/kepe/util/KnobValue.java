package ufpr.inf.kepe.util;

public interface KnobValue
{
	public Object getValue();
	public Object getMax();
	public Object getMin();
	public String type();
}
